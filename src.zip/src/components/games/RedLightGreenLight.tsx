"use client";

// ─────────────────────────────────────────────────────────────────────────────
// RedLightGreenLight.tsx  —  Squid Game Authentic 3D Edition
// ─────────────────────────────────────────────────────────────────────────────

import { motion, AnimatePresence } from "framer-motion";
import { audioEventBus } from "../../lib/audio/AudioEventBus";
import { useHUDSync } from "@/components/hud/useHUDSync";
import React, { useEffect, useRef, useState, useCallback } from "react";
import { useGameStore } from "../../store/gameStore";
import { useSceneCleanup } from "@/hooks/useSceneCleanup";
import MobileTouchControls from "@/components/touch/MobileTouchControls";
import { useGameAudio } from "../../hooks/useAmbientAudio";
import { SoundManager } from "@/managers/SoundManager";
import { inputManager } from "@/managers/InputManager";
import { ResultScreen } from "../ui/ResultScreen";
import { RLGLAudioController } from "@/lib/audio/RLGLAudioController";
import { musicManager } from "@/managers/MusicManager";

import { Canvas, useFrame } from "@react-three/fiber";
import { Sky } from "@react-three/drei";
import * as THREE from "three";

import SquidPlayer from "../r3f/models/SquidPlayer";
import DollModel from "../r3f/models/DollModel";
import SoldierModel from "../r3f/models/SoldierModel";
import { RLGLCamera } from "../r3f/camera/GameCamera";

// ─── Game Constants (Authentic Brutal Tuning) ─────────────────────────────
const DW = 1280;
const DH = 720;
const GROUND_Y = DH - 110;
const PLAYER_H = 56;
const FINISH_X = DW * 6.5;
const START_X = 160;
const DOLL_WORLD_X = 2000;

const ACCEL = 1100;
const DECEL = 3800; // Almost instant stop when letting go of the controls
const MAX_SPEED_BASE = 320;
const SPRINT_MULT = 1.55;
const JUMP_FORCE = -510;
const GRAVITY = 880;
const MAX_FALL = 1100;

// Strict Show Rules
const SAFE_VELOCITY_THRESHOLD = 5; // Brutally strict. 
const GRACE_PERIOD_MS = 200; // You have exactly 0.2 seconds to freeze after she turns.
const TURN_DUR = 0.42;
const WARNING_DUR = 0.55;

const NPC_COUNT = 14;
const NPC_LANES = 7;
const CAM_LEAD_X = 0.32;
const CAM_LERP = 6;

// ─── 3D Coordinate Math ───────────────────────────────────────────────────
const S = 0.02; 
const wx3 = (px: number) => px * S; 
const wy3 = (cy: number) => (GROUND_Y - cy) * S; 
const FINISH_X_3D = wx3(FINISH_X); 
const DOLL_X_3D = wx3(DOLL_WORLD_X); 

// ─── Types ────────────────────────────────────────────────────────────────
type LightPhase = "green" | "warning" | "turning" | "red" | "fake_out";
type EliminationPhase = "none" | "impact" | "slow_mo" | "showing";
type PlayerStatus = "alive" | "eliminating" | "eliminated" | "finished";

interface Player {
  id: number; wx: number; wy: number; vy: number; vx: number; onGround: boolean;
  status: PlayerStatus; laneY: number; opacity: number; scaleX: number; scaleY: number;
  facing: 1 | -1; animPhase: number; lastStepVx: number; stepTimer: number; isNPC: boolean;
  npcSpeed: number; npcReactDelay: number; npcReactTimer: number; elimTimer: number; hitFlashTimer: number; score: number;
}
interface DollState {
  angle: number; targetAngle: number; phase: LightPhase; stateTimer: number; phaseAge: number;
  gracePct: number; eyeOpen: boolean; eyeBlinkT: number; fakeOutTimer: number;
}
interface CameraState { x: number; shake: number; shakeTimer: number; shakeDecay: number; }
interface ParticleData { x: number; y: number; vx: number; vy: number; life: number; maxLife: number; r: number; color: string; type: "dust" | "spark" | "blood"; }
interface GameState {
  phase: "countdown" | "playing" | "eliminating" | "gameover" | "victory";
  lightPhase: LightPhase; elimPhase: EliminationPhase; elapsed: number; timeLeft: number; totalTime: number;
  countdown: number; graceMsLeft: number; slowMoMult: number; players: Player[]; doll: DollState;
  camera: CameraState; particles: ParticleData[]; difficulty: number; round: number; fakeOutProb: number;
  aliveCount: number; playerScore: number; inputLeft: boolean; inputRight: boolean; inputJump: boolean; inputSprint: boolean;
  audioEvents: Set<string>; victoryFlash: number; cameraRevealPhase: "forward" | "pullback" | "done";
}
interface GameProps { onExit?: () => void; onComplete?: (score: number, outcome: "victory" | "eliminated") => void; }

// ─── Pure simulation utilities ────────────────────────────────────────────
function lerp(a: number, b: number, t: number) { return a + (b - a) * t; }
function clamp(v: number, lo: number, hi: number) { return Math.max(lo, Math.min(hi, v)); }
function lerpAngle(a: number, b: number, t: number): number {
  let d = b - a;
  while (d > Math.PI) d -= Math.PI * 2;
  while (d < -Math.PI) d += Math.PI * 2;
  return a + d * t;
}

function makePlayer(id: number, isNPC: boolean): Player {
  const lane = isNPC ? (id % NPC_LANES) : 0;
  const laneY = GROUND_Y - lane * 3.5 - PLAYER_H;
  return {
    id, wx: START_X - (isNPC ? Math.random() * 80 : 0), wy: laneY, vy: 0, vx: 0, onGround: true, status: "alive",
    laneY, opacity: 1, scaleX: 1, scaleY: 1, facing: 1, animPhase: Math.random() * Math.PI * 2, lastStepVx: 0, stepTimer: 0,
    isNPC, npcSpeed: MAX_SPEED_BASE * (0.55 + Math.random() * 0.6), npcReactDelay: 0.1 + Math.random() * 0.25,
    npcReactTimer: 0, elimTimer: 0, hitFlashTimer: 0, score: 0,
  };
}
function makeDoll(): DollState { return { angle: 0, targetAngle: 0, phase: "green", stateTimer: 4.0, phaseAge: 0, gracePct: 0, eyeOpen: true, eyeBlinkT: 2 + Math.random() * 2, fakeOutTimer: 0, }; }
function makeCamera(): CameraState { return { x: 0, shake: 0, shakeTimer: 0, shakeDecay: 8 }; }

function makeGameState(diffNum: number): GameState {
  const players: Player[] = [makePlayer(0, false)];
  for (let i = 1; i <= NPC_COUNT; i++) players.push(makePlayer(i, true));
  return {
    phase: "countdown", lightPhase: "green", elimPhase: "none", elapsed: 0, timeLeft: 90, totalTime: 90, countdown: 3, graceMsLeft: 0, slowMoMult: 1,
    players, doll: makeDoll(), camera: makeCamera(), particles: [], difficulty: diffNum, round: 1, fakeOutProb: 0.08, aliveCount: NPC_COUNT + 1,
    playerScore: 0, inputLeft: false, inputRight: false, inputJump: false, inputSprint: false, audioEvents: new Set(), victoryFlash: 0, cameraRevealPhase: "forward",
  };
}

// ─── Unpredictable Doll Logic ─────────────────────────────────────────────
function updateLightStateMachine(gs: GameState, dt: number): void {
  const doll = gs.doll;
  doll.stateTimer -= dt;
  doll.phaseAge += dt;
  doll.eyeBlinkT -= dt;
  if (doll.eyeBlinkT <= 0) {
    doll.eyeOpen = !doll.eyeOpen;
    doll.eyeBlinkT = doll.eyeOpen ? 2 + Math.random() * 3 : 0.1;
  }
  
  // Mechanical, creepy head rotation
  const angleDist = Math.abs(doll.targetAngle - doll.angle);
  if (angleDist > 0.005) { 
    doll.angle = lerpAngle(doll.angle, doll.targetAngle, Math.min(1, dt / TURN_DUR * 5.5)); 
  } else { 
    doll.angle = doll.targetAngle; 
  }
  
  if (doll.stateTimer <= 0) {
    doll.phaseAge = 0;
    switch (doll.phase) {
      case "green": 
        doll.phase = "warning"; 
        doll.stateTimer = WARNING_DUR / gs.difficulty; 
        gs.lightPhase = "warning"; 
        gs.audioEvents.add("warning"); 
        break;
      case "warning": 
        doll.phase = "turning"; 
        doll.targetAngle = Math.PI; // Snap backwards to face players
        doll.stateTimer = TURN_DUR / gs.difficulty; 
        gs.graceMsLeft = GRACE_PERIOD_MS; 
        gs.audioEvents.add("doll_turn"); 
        break;
      case "turning": 
        doll.phase = "red"; 
        // Randomized Red Light wait time (2 to 5 seconds of sheer tension)
        doll.stateTimer = (2.0 + Math.random() * 3.0) / gs.difficulty; 
        gs.lightPhase = "red"; 
        gs.audioEvents.add("red_light"); 
        gs.audioEvents.add("heartbeat_start"); 
        break;
      case "red": 
        doll.phase = "green"; 
        doll.targetAngle = 0; // Turn back to wall
        // Randomized Green Light duration (2.5 to 6 seconds)
        doll.stateTimer = (2.5 + Math.random() * 3.5) / gs.difficulty; 
        gs.lightPhase = "green"; 
        gs.audioEvents.add("green_light"); 
        gs.audioEvents.add("heartbeat_stop"); 
        break;
    }
  }
  if (gs.graceMsLeft > 0) { gs.graceMsLeft -= dt * 1000; if (gs.graceMsLeft < 0) gs.graceMsLeft = 0; }
}

// ─── Particles (unchanged) ────────────────────────────────────────────────
function spawnDust(gs: GameState, wx: number, wy: number, count = 3): void {
  for (let i = 0; i < count; i++) { gs.particles.push({ x: wx, y: wy + PLAYER_H, vx: (Math.random() - 0.5) * 60, vy: -(10 + Math.random() * 30), life: 0, maxLife: 0.35 + Math.random() * 0.2, r: 3, color: "rgba(200,210,230,0.6)", type: "dust", }); }
}
function spawnBlood(gs: GameState, wx: number, wy: number): void {
  for (let i = 0; i < 18; i++) { const angle = Math.random() * Math.PI * 2; const spd = 40 + Math.random() * 180; gs.particles.push({ x: wx, y: wy + PLAYER_H * 0.4, vx: Math.cos(angle) * spd, vy: Math.sin(angle) * spd - 60, life: 0, maxLife: 0.6 + Math.random() * 0.5, r: 3, color: "#dc2626", type: "blood", }); }
}
function spawnSpark(gs: GameState, wx: number, wy: number, count = 6): void {
  for (let i = 0; i < count; i++) { gs.particles.push({ x: wx, y: wy, vx: (Math.random() - 0.5) * 220, vy: -(80 + Math.random() * 120), life: 0, maxLife: 0.4 + Math.random() * 0.3, r: 2, color: "#fef08a", type: "spark", }); }
}
function spawnVictoryBurst(gs: GameState, wx: number, wy: number): void {
  for (let i = 0; i < 50; i++) { const angle = -(Math.PI * 0.1) + Math.random() * Math.PI * 1.2; const speed = 120 + Math.random() * 320; gs.particles.push({ x: wx, y: wy + PLAYER_H * 0.5, vx: Math.cos(angle) * speed, vy: Math.sin(angle) * speed - 80, life: 0, maxLife: 1.0 + Math.random() * 1.0, r: 3, color: Math.random() < 0.55 ? "#FFD700" : "#00FFB2", type: "spark", }); }
}
function updateParticles(gs: GameState, dt: number): void {
  const arr = gs.particles;
  for (let i = arr.length - 1; i >= 0; i--) {
    const p = arr[i]; p.life += dt;
    if (p.life >= p.maxLife) { arr.splice(i, 1); continue; }
    p.x += p.vx * dt; p.y += p.vy * dt; p.vy += (p.type === "dust" ? 20 : 280) * dt; p.vx *= p.type === "dust" ? 0.92 : 0.97;
  }
}

// ─── Strict Player Physics ────────────────────────────────────────────────
function updatePlayer(p: Player, gs: GameState, dt: number, isHuman: boolean): void {
  if (p.status !== "alive") return;
  const prevVx = p.vx;
  const maxSpeed = (isHuman ? MAX_SPEED_BASE * (gs.inputSprint ? SPRINT_MULT : 1) : p.npcSpeed) * (0.7 + gs.difficulty * 0.15);
  
  if (isHuman) {
    if (gs.inputRight) { p.vx = Math.min(p.vx + ACCEL * dt, maxSpeed); p.facing = 1; }
    else if (gs.inputLeft) { p.vx = Math.max(p.vx - ACCEL * dt, -maxSpeed * 0.5); p.facing = -1; }
    else {
      if (p.vx > 0) p.vx = Math.max(0, p.vx - DECEL * dt);
      if (p.vx < 0) p.vx = Math.min(0, p.vx + DECEL * dt);
    }
    if (gs.inputJump && p.onGround) { p.vy = JUMP_FORCE; p.onGround = false; p.scaleX = 0.72; p.scaleY = 1.28; gs.audioEvents.add("jump"); spawnDust(gs, p.wx, p.wy, 4); }
  } else {
    p.npcReactTimer -= dt;
    const npcShouldMove = gs.lightPhase === "green" || (gs.lightPhase === "turning" && gs.graceMsLeft > 100);
    if (npcShouldMove && p.npcReactTimer <= 0) { p.vx = Math.min(p.vx + ACCEL * dt * 0.7, p.npcSpeed); p.facing = 1; }
    else if (!npcShouldMove) { if (p.npcReactTimer <= -p.npcReactDelay) { if (p.vx > 0) p.vx = Math.max(0, p.vx - DECEL * dt * 0.9); } }
    if (p.onGround && Math.random() < 0.003) { p.vy = JUMP_FORCE * 0.6; p.onGround = false; }
  }

  if (!p.onGround) {
    p.vy += GRAVITY * dt; p.vy = Math.min(p.vy, MAX_FALL); p.wy += p.vy * dt;
    if (p.wy >= p.laneY) {
      p.wy = p.laneY; p.vy = 0; p.onGround = true;
      if (prevVx !== 0 || Math.abs(p.vy) > 50) {
        p.scaleX = 1.25; p.scaleY = 0.78;
        if (isHuman) gs.audioEvents.add("land");
        spawnDust(gs, p.wx, p.wy + PLAYER_H, 3);
      }
    }
  }

  p.wx = Math.max(START_X, p.wx + p.vx * dt);
  p.scaleX = lerp(p.scaleX, 1, Math.min(1, dt * 12)); p.scaleY = lerp(p.scaleY, 1, Math.min(1, dt * 12));
  
  if (Math.abs(p.vx) > 10) {
    p.animPhase += dt * Math.abs(p.vx) * 0.055;
    if (isHuman && p.onGround) {
      p.stepTimer -= dt;
      if (p.stepTimer <= 0) { p.stepTimer = 0.22 - Math.min(0.12, Math.abs(p.vx) * 0.0003); gs.audioEvents.add("step"); spawnDust(gs, p.wx, p.wy + PLAYER_H, 1); }
    }
  }
  if (p.hitFlashTimer > 0) p.hitFlashTimer = Math.max(0, p.hitFlashTimer - dt * 3);

  // Strict World-Space Finish Line Check
  if (p.wx >= FINISH_X && p.status === "alive") {
    p.status = "finished"; p.wx = FINISH_X; p.vx = 0;
    if (isHuman) {
      gs.audioEvents.add("victory"); gs.phase = "victory"; gs.lightPhase = "green"; gs.graceMsLeft = 999; gs.victoryFlash = 3; spawnVictoryBurst(gs, p.wx, p.wy);
    }
  }
}

function checkEliminationForPlayer(p: Player, gs: GameState, isHuman: boolean): boolean {
  if (gs.lightPhase !== "red") return false;
  if (gs.graceMsLeft > 0) return false;
  if (p.status !== "alive") return false;
  const speed = Math.abs(p.vx) + Math.abs(p.vy) * 0.5;
  const caught = speed > SAFE_VELOCITY_THRESHOLD;
  
  if (caught) {
    p.status = "eliminating"; p.hitFlashTimer = 1; spawnBlood(gs, p.wx, p.wy); spawnSpark(gs, p.wx, p.wy, 8);
    if (isHuman) { gs.phase = "eliminating"; gs.elimPhase = "impact"; gs.camera.shake = 16; gs.camera.shakeTimer = 0.55; gs.slowMoMult = 1; gs.audioEvents.add("eliminated"); }
    else {
      const human = gs.players[0];
      const dist = Math.abs(p.wx - human.wx);
      if (human.status === "alive" && dist < 150) { gs.camera.shake = Math.max(gs.camera.shake, 14); gs.camera.shakeTimer = Math.max(gs.camera.shakeTimer, 0.4); spawnBlood(gs, human.wx + (Math.random() - 0.5) * 80, human.wy - 20); spawnBlood(gs, human.wx + (Math.random() - 0.5) * 80, human.wy); gs.audioEvents.add("crowd_gasp"); }
    }
  }
  return caught;
}

function updateEliminationSequence(gs: GameState, dt: number): void {
  if (gs.phase !== "eliminating") return;
  const human = gs.players[0]; human.elimTimer += dt;
  switch (gs.elimPhase) {
    case "impact": if (human.elimTimer > 0.5) { gs.elimPhase = "slow_mo"; gs.slowMoMult = 0.12; spawnBlood(gs, human.wx, human.wy); spawnSpark(gs, human.wx, human.wy, 12); gs.camera.shake = 22; gs.camera.shakeTimer = 0.4; } break;
    case "slow_mo": gs.slowMoMult = lerp(gs.slowMoMult, 0.05, dt * 2); human.opacity = lerp(human.opacity, 0.25, dt * 1.8); if (human.elimTimer > 0.7) { gs.elimPhase = "showing"; gs.slowMoMult = 1; human.status = "eliminated"; } break;
    case "showing": if (human.elimTimer > 1.0) { gs.phase = "gameover"; gs.elimPhase = "none"; } break;
  }
}

function updateCamera(gs: GameState, dt: number): void {
  const human = gs.players[0]; const cam = gs.camera;
  if (gs.phase === "countdown") {
    const elapsed = 3 - gs.countdown;
    if (elapsed < 1.8) { gs.cameraRevealPhase = "forward"; const revealTarget = FINISH_X * 0.65 - DW * 0.5; cam.x = lerp(cam.x, clamp(revealTarget, 0, DOLL_WORLD_X - DW * 0.5), Math.min(1, dt * 1.8)); }
    else { gs.cameraRevealPhase = "pullback"; cam.x = lerp(cam.x, 0, Math.min(1, dt * 5)); }
    return;
  }
  const targetX = clamp(human.wx - DW * CAM_LEAD_X, 0, DOLL_WORLD_X - DW * 0.5);
  cam.x = lerp(cam.x, targetX, Math.min(1, dt * CAM_LERP));
  if (cam.shakeTimer > 0) { cam.shakeTimer -= dt; cam.shake = lerp(cam.shake, 0, Math.min(1, dt * cam.shakeDecay)); } else { cam.shake = 0; }
}

function updateDifficulty(gs: GameState): void {
  gs.difficulty = clamp(1 + gs.elapsed * 0.009, 1, 3.2); gs.fakeOutProb = clamp(0.06 + gs.elapsed * 0.002, 0, 0.35); gs.round = Math.floor(gs.elapsed / 18) + 1;
}

function gameTick(gs: GameState, rawDt: number): void {
  if (gs.phase === "gameover" || gs.phase === "victory") return;
  const dt = rawDt * gs.slowMoMult;
  gs.audioEvents.clear();
  
  if (gs.phase === "countdown") { gs.countdown -= rawDt; updateCamera(gs, rawDt); return; }
  gs.elapsed += rawDt; gs.timeLeft -= rawDt;
  if (gs.timeLeft <= 0) { gs.phase = "gameover"; return; }
  if (gs.victoryFlash > 0) gs.victoryFlash--;
  
  updateDifficulty(gs); updateLightStateMachine(gs, dt); updateEliminationSequence(gs, rawDt); updateParticles(gs, dt); updateCamera(gs, rawDt);
  let alive = 0;
  for (let i = 0; i < gs.players.length; i++) {
    const p = gs.players[i]; const isHum = i === 0;
    if (p.status === "finished") { alive++; continue; }
    if (p.status === "alive" || p.status === "eliminating") { updatePlayer(p, gs, dt, isHum); }
    if (p.status === "eliminating") {
      p.elimTimer += rawDt; p.opacity = Math.max(0.18, 1 - p.elimTimer * 0.9);
      if (p.elimTimer > 1.2 && !isHum) p.status = "eliminated";
    }
    if (p.status === "alive") { checkEliminationForPlayer(p, gs, isHum); alive++; }
  }
  gs.aliveCount = alive; gs.playerScore += rawDt * gs.difficulty * 7;
}

// ─── TOUCH INPUT ─────────────────────────────────────────────────────────
interface RLGLTouchState { left: boolean; right: boolean; jump: boolean; sprint: boolean; }
function TouchControlsGate({ inputRef }: { inputRef: React.MutableRefObject<RLGLTouchState> }) {
  const [isTouch, setIsTouch] = useState(false);
  useEffect(() => {
    const check = window.matchMedia("(pointer: coarse)").matches || window.innerWidth < 900 || /Android|iPhone|iPad|iPod/i.test(navigator.userAgent);
    setTimeout(() => setIsTouch(check), 0);
  }, []);
  if (!isTouch) return null;
  return <MobileTouchControls touchStateRef={inputRef} visible={true} />;
}

// ─── 3D SCENE ─────────────────────────────────────────────────────────────
interface SceneProps {
  gsRef: React.MutableRefObject<GameState>;
  audioCallbackRef: React.MutableRefObject<(evts: Set<string>) => void>;
  uiCallbackRef: React.MutableRefObject<{
    onPhaseChange: (p: GameState["phase"]) => void;
    onCountdown: (n: number) => void;
    onElimChange: (v: boolean) => void;
    onScoreChange: (s: number) => void;
  }>;
  inputRef: React.MutableRefObject<RLGLTouchState>;
}

function Ground3D() {
  return (
    <>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[80, -0.01, 0]} receiveShadow>
        <planeGeometry args={[340, 28]} />
        <meshStandardMaterial color="#d4b881" roughness={1} metalness={0} />
      </mesh>
    </>
  );
}

function SceneLighting({ lightPhase }: { lightPhase: LightPhase }) {
  // Flatter, brighter, artificial "shadowless" lighting to mimic the indoor set
  const dangerFactor = lightPhase === "red" ? 0.35 : 0;
  const ambientColor = new THREE.Color().lerpColors(new THREE.Color("#ffffff"), new THREE.Color("#ffb3b3"), dangerFactor);
  return (
    <>
      <ambientLight color={ambientColor} intensity={1.3} />
      {/* Lights placed directly overhead like giant warehouse ceiling lights */}
      <directionalLight position={[0, 50, 0]} intensity={1.0} castShadow shadow-mapSize={[2048, 2048]} color="#fff9ed" />
      <directionalLight position={[20, 30, 20]} intensity={0.5} color="#e0f0ff" />
    </>
  );
}

function FinishLine3D({ show }: { show: boolean }) {
  if (!show) return null;
  return (
    <group position={[FINISH_X_3D, 0, 0]}>
      <mesh position={[-0.2, 3.5, -12]} castShadow>
        <cylinderGeometry args={[0.06, 0.06, 7, 8]} />
        <meshStandardMaterial color="#fbbf24" emissive="#fbbf24" emissiveIntensity={0.9} roughness={0.3} metalness={0.6} />
      </mesh>
      <mesh position={[-0.2, 3.5, 12]} castShadow>
        <cylinderGeometry args={[0.06, 0.06, 7, 8]} />
        <meshStandardMaterial color="#fbbf24" emissive="#fbbf24" emissiveIntensity={0.9} roughness={0.3} metalness={0.6} />
      </mesh>
      <mesh position={[-0.2, 7.1, 0]}>
        <boxGeometry args={[0.06, 0.25, 24]} />
        <meshStandardMaterial color="#fbbf24" emissive="#fbbf24" emissiveIntensity={0.7} transparent opacity={0.9} />
      </mesh>
      <pointLight color="#fbbf24" intensity={6} distance={20} decay={2} position={[0, 5, 0]} />
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.01, 0]}>
        <planeGeometry args={[0.4, 28]} />
        <meshStandardMaterial color="#fbbf24" emissive="#fbbf24" emissiveIntensity={0.6} transparent opacity={0.6} />
      </mesh>
    </group>
  );
}

function RLGLScene3D({ gsRef, audioCallbackRef, uiCallbackRef, inputRef }: SceneProps) {
  const prevPhaseRef = useRef<GameState["phase"]>("countdown");
  const prevCountdownRef = useRef(3);

  useFrame((_, rawDelta) => {
    const gs = gsRef.current;
    if (!gs || !gs.players || gs.players.length === 0) return; // Next.js Fast-Refresh Safety Guard
    
    const km = inputManager.snapshot();
    const touch = inputRef.current;
    
    gs.inputLeft = km.heldKeys.has("ArrowLeft") || km.heldKeys.has("KeyA") || touch.left;
    gs.inputRight = km.heldKeys.has("ArrowRight") || km.heldKeys.has("KeyD") || touch.right;
    gs.inputSprint = km.heldKeys.has("ShiftLeft") || km.heldKeys.has("ShiftRight") || touch.sprint;
    const kbJump = km.up || km.action;
    gs.inputJump = kbJump || touch.jump;
    
    if (kbJump) inputManager.consumeIntent("up", "action");
    if (touch.jump) touch.jump = false;

    gameTick(gs, rawDelta);

    if (gs.audioEvents.size > 0) { audioCallbackRef.current(gs.audioEvents); }
    
    const ui = uiCallbackRef.current;
    if (gs.phase !== prevPhaseRef.current) {
      prevPhaseRef.current = gs.phase;
      ui.onPhaseChange(gs.phase);
      ui.onScoreChange(Math.floor(gs.playerScore));
    }
    
    if (gs.phase === "countdown") {
      const cn = Math.ceil(gs.countdown);
      if (cn !== prevCountdownRef.current && cn >= 0) {
        prevCountdownRef.current = cn;
        ui.onCountdown(cn);
      }
      if (gs.countdown <= 0 && prevPhaseRef.current === "countdown") {
        gs.phase = "playing"; prevPhaseRef.current = "playing"; ui.onPhaseChange("playing");
      }
    }
    
    const elim = gs.players[0].status === "eliminated" || gs.players[0].status === "eliminating";
    ui.onElimChange(elim);
  });

  const gs = gsRef.current;
  if (!gs || !gs.players || gs.players.length === 0) return null;

  const human = gs.players[0];
  const camCenterX3D = wx3(gs.camera.x + DW / 2);
  const isHostile = gs.lightPhase === "red" || gs.lightPhase === "warning";
  const isShooting = gs.phase === "eliminating";
  const humanPos3D = new THREE.Vector3(wx3(human.wx), wy3(human.wy), 0);

  // FIX: The 3D model is now directly wired to the physics engine's lerped rotation value!
  const dollAngle = gs.doll.angle; 

  // Create an array of Z positions for the terrifying row of soldiers
  const soldierPositions = [-10, -6, -2, 2, 6, 10]; 

  return (
    <>
      <RLGLCamera targetX={camCenterX3D} groundY={0} cameraShake={gs.camera.shake} />
      <SceneLighting lightPhase={gs.lightPhase} />
      
      {/* ── Sky (Artificial Painted Walls / Flat Daylight) ── */}
      <Sky distance={450000} sunPosition={[0, 10, 0]} turbidity={0.5} rayleigh={0.3} mieCoefficient={0.01} />
      
      <Ground3D />
      <DollModel position={[DOLL_X_3D, 0, 0]} lightPhase={gs.lightPhase} headAngle={dollAngle} isHostile={isHostile} atmosphericT={gs.elapsed} />
      <FinishLine3D show={true} />
      
      {/* A full terrifying row of Executioners lined up at the finish line */}
      {soldierPositions.map((zPos, idx) => (
        <SoldierModel key={`soldier-${idx}`} position={[FINISH_X_3D + 1, 0, zPos]} facing={-1} isShooting={isShooting} targetPosition={isShooting ? humanPos3D : null} shootProgress={isShooting ? human.elimTimer : 0} />
      ))}

      {/* Elite Guards flanking the doll */}
      <SoldierModel position={[DOLL_X_3D - 1, 0, -5]} facing={-1} isShooting={isShooting} targetPosition={isShooting ? humanPos3D : null} shootProgress={isShooting ? human.elimTimer : 0} />
      <SoldierModel position={[DOLL_X_3D - 1, 0, 5]} facing={-1} isShooting={isShooting} targetPosition={isShooting ? humanPos3D : null} shootProgress={isShooting ? human.elimTimer : 0} />
      
      {gs.players.map((p, i) => {
        if (p.status === "eliminated" || p.status === "finished") return null;
        const isHum = i === 0;
        const lane = isHum ? 0 : (p.id % NPC_LANES);
        const x3 = wx3(p.wx); const y3 = wy3(p.wy); const z3 = (lane * 2.2) - 6; // Spread the crowd out slightly more
        const spd = Math.abs(p.vx);
        const animState = p.status === "eliminating" ? "hit" : !p.onGround ? "jumping" : spd > 10 ? "running" : "idle";
        
        return (
          <SquidPlayer key={p.id} position={[x3, y3, z3]} facing={p.facing} animState={animState} animPhase={p.animPhase} opacity={p.opacity} squash={[p.scaleX, p.scaleY, 1]} isHuman={isHum} isEliminated={p.status === "eliminating"} />
        );
      })}
    </>
  );
}

// ─── HUD overlay (DOM) ────────────────────────────────────────────────────
const C = { accent: "#00f5c4", danger: "#ff3d5a", warn: "#f97316", green: "#22c55e", red: "#ef4444", muted: "rgba(255,255,255,0.32)", white: "#ffffff", };

function HUDOverlay({ gs }: { gs: GameState }) {
  const human = gs.players[0];
  const progress = clamp((human.wx - START_X) / (FINISH_X - START_X), 0, 1);
  const tl = Math.max(0, gs.timeLeft);
  const tMin = Math.floor(tl / 60); const tSec = Math.floor(tl % 60);
  const tCol = tl < 10 ? C.danger : tl < 20 ? C.warn : C.white;
  const liLabel = gs.lightPhase === "green" ? "● GREEN LIGHT" : gs.lightPhase === "red" ? "● RED LIGHT" : gs.lightPhase === "warning" ? "◉ WARNING" : gs.lightPhase === "fake_out" ? "○ ..." : "◐ TURNING";
  const liCol = gs.lightPhase === "green" ? C.green : gs.lightPhase === "red" ? C.red : gs.lightPhase === "warning" || gs.lightPhase === "turning" ? C.warn : C.muted;
  
  return (
    <div style={{ position: "absolute", inset: 0, pointerEvents: "none", zIndex: 50, fontFamily: "var(--font-mono, 'JetBrains Mono', monospace)", }}>
      <div style={{ position: "absolute", top: 18, left: 40, right: 40, height: 9, background: "rgba(0,0,0,0.55)", borderRadius: 4.5, }}>
        <div style={{ height: "100%", borderRadius: 4.5, width: `${progress * 100}%`, background: gs.lightPhase === "red" ? C.red : C.green, boxShadow: `0 0 10px ${gs.lightPhase === "red" ? C.red : C.green}`, transition: "width 0.05s linear", }} />
      </div>
      <div style={{ position: "absolute", top: 38, left: "50%", transform: "translateX(-50%)", color: tCol, fontSize: "clamp(22px,3vw,30px)", fontWeight: 700, textShadow: tl < 10 ? `0 0 18px ${C.danger}` : "none", fontFamily: "Rajdhani, sans-serif", }}>
        {`${tMin.toString().padStart(2, "0")}:${tSec.toString().padStart(2, "0")}`}
      </div>
      <div style={{ position: "absolute", top: 72, left: "50%", transform: "translateX(-50%)", color: liCol, fontSize: 13, fontWeight: 700, letterSpacing: "0.1em", textShadow: `0 0 14px ${liCol}`, textTransform: "uppercase", fontFamily: "Rajdhani, sans-serif", }}>
        {liLabel}
      </div>
      <div style={{ position: "absolute", top: 56, left: 44, color: C.muted, fontSize: 12 }}>{`ALIVE ${gs.aliveCount} / ${NPC_COUNT + 1}`}</div>
      <div style={{ position: "absolute", top: 56, right: 44, color: C.accent, fontSize: 12 }}>{gs.playerScore.toFixed(0).padStart(7, "0")}</div>
    </div>
  );
}

// ─── MAIN COMPONENT ───────────────────────────────────────────────────────
export default function RedLightGreenLight({ onExit, onComplete }: GameProps) {
  const [uiPhase, setUIPhase] = useState<GameState["phase"]>("countdown");
  const [countdownN, setCountdownN] = useState(3);
  const [finalScore, setFinalScore] = useState(0);
  const [showElim, setShowElim] = useState(false);
  const settingsDiff = useGameStore((s) => s.settings.difficulty);
  const addScore = useGameStore((s) => s.addScore);
  const loadFromStorage = useGameStore((s) => s.loadFromStorage);
  const setView = useGameStore((s) => s.setView);
  
  const diffNum = settingsDiff === "easy" ? 0.75 : settingsDiff === "hard" ? 1.5 : 1.0;
  const containerRef = useRef<HTMLDivElement>(null);
  const gsRef = useRef<GameState>(makeGameState(diffNum));
  const audio = useGameAudio();
  const inputRef = useRef<RLGLTouchState>({ left: false, right: false, jump: false, sprint: false });
  const rlglAudioRef = useRef<RLGLAudioController | null>(null);
  const hudSync = useHUDSync({ flushInterval: 80 });

  const audioCallbackRef = useRef<(evts: Set<string>) => void>(() => {});
  
  useEffect(() => {
    audioCallbackRef.current = (evts: Set<string>) => {
      for (const ev of evts) {
        switch (ev) {
          case "green_light": rlglAudioRef.current?.transition("GREEN_LIGHT"); rlglAudioRef.current?.setRate(gsRef.current.difficulty); audioEventBus.emit("greenLightActivated"); break;
          case "warning": case "doll_turn": audio.onDollTurn(); break;
          case "heartbeat_start": SoundManager.getInstance().setHeartbeatIntensity(1.0); break;
          case "heartbeat_stop": SoundManager.getInstance().setHeartbeatIntensity(0.0); break;
          case "crowd_gasp": SoundManager.getInstance().play("crowd_gasp"); break;
          case "red_light": rlglAudioRef.current?.transition("RED_LIGHT"); audioEventBus.emit("redLightActivated"); break;
          case "step": audio.onStep(); break;
          case "jump": audio.onJump(); break;
          case "land": audio.onLand(); break;
          case "eliminated": rlglAudioRef.current?.transition("ELIMINATED"); audio.onEliminated(); audioEventBus.emit("playerEliminated", "Player_1"); break;
          case "victory": rlglAudioRef.current?.transition("VICTORY"); audio.onVictory(); break;
        }
      }
    };
  }, [audio]);

  const uiCallbackRef = useRef({
    onPhaseChange: (p: GameState["phase"]) => {
      setUIPhase(p);
      if (p === "gameover") { const sc = Math.floor(gsRef.current.playerScore); setFinalScore(sc); addScore(sc); if (onComplete) onComplete(sc, "eliminated"); }
      if (p === "victory") { const sc = Math.floor(gsRef.current.playerScore); setFinalScore(sc); addScore(sc); if (onComplete) onComplete(sc, "victory"); }
    },
    onCountdown: (n: number) => { setCountdownN(n); if (n > 0) audio.onCountdownBeep(); else audio.onCountdownGo(); },
    onElimChange: (v: boolean) => setShowElim(v),
    onScoreChange: (s: number) => { hudSync.write({ score: s, lives: gsRef.current.aliveCount, time: Math.ceil(gsRef.current.timeLeft), health: gsRef.current.players[0].status === "alive" ? 100 : 0, maxHealth: 100, }); },
  });

  uiCallbackRef.current.onPhaseChange = (p) => {
    setUIPhase(p);
    if (p === "gameover") { const sc = Math.floor(gsRef.current.playerScore); setFinalScore(sc); addScore(sc); if (onComplete) onComplete(sc, "eliminated"); }
    if (p === "victory") { const sc = Math.floor(gsRef.current.playerScore); setFinalScore(sc); addScore(sc); if (onComplete) onComplete(sc, "victory"); }
  };
  uiCallbackRef.current.onCountdown = (n) => { setCountdownN(n); if (n > 0) audio.onCountdownBeep(); else audio.onCountdownGo(); };

  useEffect(() => {
    rlglAudioRef.current = RLGLAudioController.getInstance(); setView("game"); loadFromStorage(); audio.preloadGame();
    return () => { RLGLAudioController.releaseInstance(); rlglAudioRef.current = null; musicManager.stop(0); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const target = containerRef.current; if (!target) return; inputManager.attach(target);
    return () => inputManager.detach();
  }, []);

  useEffect(() => {
    if (!onExit) return;
    const onEsc = (e: KeyboardEvent) => {
      if (e.code !== "Escape") return;
      e.preventDefault(); audio.stopHeartbeat(); inputManager.reset(); musicManager.stop(0); onExit();
    };
    window.addEventListener("keydown", onEsc);
    return () => window.removeEventListener("keydown", onEsc);
  }, [onExit, audio]);

  const resetGame = useCallback(() => {
    gsRef.current = makeGameState(diffNum); setUIPhase("countdown"); setCountdownN(3); setFinalScore(0); setShowElim(false);
    inputManager.reset(); audio.stopHeartbeat(); musicManager.stop(0); rlglAudioRef.current?.reset();
  }, [diffNum, audio]);

  const rawCanvasRef = useRef<HTMLCanvasElement | null>(null);
  useSceneCleanup(rawCanvasRef as React.RefObject<HTMLCanvasElement>);

  return (
    <div ref={containerRef} style={{ position: "relative", width: "100vw", height: "100dvh", background: "#000", overflow: "hidden", }}>
      <Canvas shadows dpr={[1, 2]} gl={{ antialias: true, alpha: false }} camera={{ fov: 52, near: 0.1, far: 2000, position: [12.8, 7, 20] }} onCreated={({ gl }) => { gl.shadowMap.enabled = true; gl.shadowMap.type = THREE.PCFSoftShadowMap; rawCanvasRef.current = gl.domElement; }} style={{ position: "absolute", inset: 0, width: "100%", height: "100%" }}>
        <RLGLScene3D gsRef={gsRef} audioCallbackRef={audioCallbackRef} uiCallbackRef={uiCallbackRef} inputRef={inputRef} />
      </Canvas>

      {(uiPhase === "playing" || uiPhase === "eliminating") && (<HUDOverlay gs={gsRef.current} />)}

      {onExit && (<button onClick={() => { audio.stopHeartbeat(); inputManager.reset(); musicManager.stop(0); onExit(); }} style={{ position: "absolute", top: 16, left: 16, zIndex: 250, padding: "10px 18px", background: "rgba(0,0,0,0.65)", border: "1px solid rgba(255,255,255,0.3)", borderRadius: 4, color: "#fff", fontFamily: "var(--font-mono, 'JetBrains Mono', monospace)", fontSize: 12, letterSpacing: "0.14em", textTransform: "uppercase", cursor: "pointer", backdropFilter: "blur(6px)", }}>← MENU (ESC)</button>)}

      <AnimatePresence>
        {uiPhase === "countdown" && (
          <motion.div key={`cd-${countdownN}`} initial={{ scale: 2.4, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.4, opacity: 0 }} transition={{ duration: 0.38, ease: [0.34, 1.56, 0.64, 1] }} style={{ position: "absolute", inset: 0, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", pointerEvents: "none", zIndex: 80, }}>
            <div style={{ fontFamily: "var(--font-display)", fontSize: "clamp(88px, 18vw, 172px)", fontWeight: 700, lineHeight: 1, color: countdownN > 0 ? "#fff" : C.green, textShadow: `0 0 60px ${countdownN > 0 ? C.warn : C.green}`, }}>
              {countdownN > 0 ? countdownN : "GO!"}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showElim && uiPhase === "eliminating" && (
          <motion.div key="elim-vignette" initial={{ opacity: 0 }} animate={{ opacity: [0, 0.85, 0.6, 0] }} transition={{ duration: 0.7, times: [0, 0.1, 0.4, 1] }} style={{ position: "absolute", inset: 0, pointerEvents: "none", zIndex: 70, background: "radial-gradient(ellipse at center, transparent 30%, rgba(220,38,38,0.75) 100%)", }} />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {(uiPhase === "gameover" || uiPhase === "victory") && (
          <ResultScreen outcome={uiPhase === "victory" ? "victory" : "eliminated"} statLine={uiPhase === "victory" ? `SCORE ${finalScore.toLocaleString("en-US")} · FINISH LINE CROSSED` : showElim ? `SCORE ${finalScore.toLocaleString("en-US")} · MOVED DURING RED LIGHT` : `SCORE ${finalScore.toLocaleString("en-US")} · TIME EXPIRED`} prize={uiPhase === "victory" ? 45600000000 : undefined} onTryAgain={resetGame} onMenu={() => { musicManager.stop(0); if (onExit) onExit(); }} />
        )}
      </AnimatePresence>
      <TouchControlsGate inputRef={inputRef} />
    </div>
  );
}