"use client";

import { useEffect, useRef, useCallback, useMemo } from "react";
import { SoundManager, type SoundId } from "../managers/SoundManager";
import { useGameStore } from "../store/gameStore";

// ─── Hook ─────────────────────────────────────────────────────────────────────

export interface SoundManagerHandle {
  play:    (id: SoundId, volumeMult?: number, pan?: number) => void;
  loop:    (id: SoundId, volumeMult?: number) => void;
  stop:    (id: SoundId) => void;
  stopAll: () => void;
  fadeTo:  (id: SoundId, vol: number, ms: number) => void;
  stopLoop: (id: SoundId, fadeMs?: number) => void;
  setHeartbeat: (level: number) => void;
  
  preload: (ids: SoundId[]) => void;
  manager: () => SoundManager;
}

export function useSoundManager(): SoundManagerHandle {
  const master = useGameStore((s) => s.settings.masterVolume);
  const sfx = useGameStore((s) => s.settings.sfxVolume);
  const music = useGameStore((s) => s.settings.musicVolume);
  const muted = master === 0;

  // 1. FIX: getInstance() now takes 0 arguments
  const smRef = useRef<SoundManager>(SoundManager.getInstance());

  useEffect(() => {
    const sm = smRef.current;
    if (sm.setMasterVolume) sm.setMasterVolume(master);
    if (sm.setSFXVolume) sm.setSFXVolume(sfx);
    if (sm.setMusicVolume) sm.setMusicVolume(music);
  }, [master, sfx, music]);

  useEffect(() => {
    if (smRef.current.setMuted) smRef.current.setMuted(muted);
  }, [muted]);

  return useMemo<SoundManagerHandle>(() => ({
    // 2. FIX: Aligned play() arguments to match our new clean architecture
    play:    (id, vol = 1, pan = 0) => smRef.current.play(id, vol, pan),
    loop:    (id, vol = 1)          => smRef.current.loop(id, vol),
    stop:    (id)                   => smRef.current.stop(id),
    stopAll: ()                     => smRef.current.stopAll(),
    stopLoop: (id, fadeMs) => SoundManager.getInstance().stopLoop(id, fadeMs),
    // 3. FIX: Mapped fadeTo to the correct fade() method on the manager
    fadeTo:  (id, vol, ms)          => smRef.current.fade(id, vol, ms),
    setHeartbeat: (level)           => smRef.current.setHeartbeatIntensity(level),
    preload: (ids)                  => smRef.current.preload(ids),
    manager: ()                     => smRef.current,
    
  }), []);
}

// ─── Convenience: useUISound ──────────────────────────────────────────────────

export function useUISound() {
  const sm = useSoundManager();

  // FIX: Updated to our newly consolidated SoundId strings
  const onClick   = useCallback(() => sm.play("click"),   [sm]);
  const onHover   = useCallback(() => sm.play("hover"),   [sm]);
  const onConfirm = useCallback(() => sm.play("confirm"), [sm]);
  const onBack    = useCallback(() => sm.play("back"),    [sm]);

  return useMemo(() => ({ onClick, onHover, onConfirm, onBack }), [onClick, onHover, onConfirm, onBack]);
}